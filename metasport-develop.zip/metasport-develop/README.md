# Metasport

<p align='center'>
  Bienvenue sur le repository Github de Metasport !<br/>
  <img src='frontend/assets/trademark/logo.png' width='500'/>
</p>

## Pitch

Notre projet est de réaliser une application mobile de mise en relation ponctuelle entre sportifs sur la base de la création de “séances”.
Un sportif peut créer une séance en précisant sa date, son horaire, son type de sport et sa localisation.
Cela lui permet de proposer au reste des utilisateurs de partager avec lui une séance sous réserve de validation de participation par le créateur de la séance.

## Resources

-   [Firebase auth](https://console.firebase.google.com/u/0/project/code-camp-186/overview)
-   [MarvelApp Prototype](https://marvelapp.com/prototype/6483cj5)
-   [Whimsical](https://whimsical.com/codecamp-GDAntiAzvZEvBCbTxw6mvx)
-   [Fiche projet](https://docs.google.com/presentation/d/192khhCzlWo9esDgTwsTNdbA0BJTuzwxvZfZfsKPbjKQ/edit)

## Launch

**Setup environment**

Assuming that you have Node 14 LTS or greater installed, you can use npm to install the Expo CLI command line utility:

```bash
npm install -g expo-cli
```

source : https://reactnative.dev/docs/environment-setup

**Start frontend**

- Configure backend URL in [globals.js](./frontend/src/utils/globals.js), you can edit it later by taping 7 times on metasport logo in login screen  
- Launch
```bash
cd frontend && npm install && npm start # you can also use: expo start
```

**Start backend**

```bash
docker-compose build
docker-compose up -d
docker-compose logs -f
```

backend swagger available at http://localhost:8888/docs
