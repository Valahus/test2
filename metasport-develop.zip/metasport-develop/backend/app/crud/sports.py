# -*- coding: utf-8 -*-
# !/usr/bin/python3

from sqlalchemy.orm import Session

from app.models import Sport
from app.schemas import SportCreate, SportUpdate
from app.crud.base import CRUDBase


class CRUDSport(CRUDBase[Sport, SportCreate, SportUpdate]):
    pass


sport = CRUDSport(Sport)
