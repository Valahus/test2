# -*- coding: utf-8 -*-
# !/usr/bin/python3

from sqlalchemy.orm import Session

from app.models import Session as SessionModel
from app.schemas import SessionCreate, SessionUpdate
from app.crud.base import CRUDBase


class CRUDSession(CRUDBase[SessionModel, SessionCreate, SessionUpdate]):
    pass


session = CRUDSession(SessionModel)
