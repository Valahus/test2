# -*- coding: utf-8 -*-
# !/usr/bin/python3

from fastapi import FastAPI

from app.database import engine, Base
from app.routers.sessions import router as SessionRouter
from app.routers.sports import router as SportRouter
from app.utils.init_db import create_if_not_exist
from fastapi.middleware.cors import CORSMiddleware


create_if_not_exist()

app = FastAPI()

origins = ["*"]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(SessionRouter, tags=["Sessions"], prefix="/sessions")
app.include_router(SportRouter, tags=["Sports"], prefix="/sports")


@app.get("/", tags=["Root"])
async def read_root():
    return {"message": "Welcome to this fantastic app!"}
