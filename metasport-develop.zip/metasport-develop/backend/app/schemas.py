# -*- coding: utf-8 -*-
# !/usr/bin/python3

from datetime import datetime
from pydantic import BaseModel
from typing import List, Optional, Tuple

from app.models import SessionLevel


class SportBase(BaseModel):
    name: str


class SportCreate(SportBase):
    pass


class SportUpdate(SportBase):
    pass


class Sport(SportBase):
    id: int

    class Config:
        orm_mode = True


class SessionBase(BaseModel):
    user_id: str

    start: datetime
    end: datetime
    indoor: bool
    level: SessionLevel
    location_name: str
    participants_ids: List[str]

    lat: float
    lon: float

    max_participants: Optional[int] = None
    description: Optional[str] = None


class SessionCreate(SessionBase):
    sport_id: int


class SessionUpdate(SessionBase):
    pass


class Session(SessionBase):
    id: int
    sport: Sport

    class Config:
        orm_mode = True


class SessionFilters(BaseModel):
    sport_id: Optional[List[int]] = None
    level: Optional[List[SessionLevel]] = None
