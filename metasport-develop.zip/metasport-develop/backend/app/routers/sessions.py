# -*- coding: utf-8 -*-
# !/usr/bin/python3

from typing import List

from sqlalchemy.orm import Session
from sqlalchemy.sql import text
from sqlalchemy import asc
from fastapi import Depends
from fastapi import HTTPException
from fastapi import APIRouter

from app.routers.router import get_db
from app.crud.sessions import session
from app import schemas


router = APIRouter()


@router.post("/", response_model=schemas.Session)
def create_session(
    session_create: schemas.SessionCreate, db: Session = Depends(get_db)
):
    return session.create(db, obj_in=session_create)


@router.put("/{session_id}", response_model=schemas.Session)
def update_session(
    session_id: int,
    session_update: schemas.SessionUpdate,
    db: Session = Depends(get_db),
):
    db_session = session.get(db, id=session_id)
    if db_session is None:
        raise HTTPException(status_code=404, detail="Session not found")
    return session.update(db, db_obj=db_session, obj_in=session_update)


@router.get("/{session_id}", response_model=schemas.Session)
def read_session(session_id: int, db: Session = Depends(get_db)):
    db_session = session.get(db, id=session_id)
    if db_session is None:
        raise HTTPException(status_code=404, detail="Session not found")
    return db_session


@router.delete("/{session_id}", status_code=200)
def delete_session(session_id: int, db: Session = Depends(get_db)):
    db_session = session.get(db, id=session_id)
    if db_session is None:
        raise HTTPException(status_code=404, detail="Session not found")
    session.remove(db, id=session_id)


@router.post("/filters", response_model=List[schemas.Session])
def read_sessions(
    session_filters: schemas.SessionFilters,
    latitude: float = None,
    longitude: float = None,
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db),
):
    query = db.query(session.model).order_by(asc(session.model.start))

    session_filters = dict(session_filters)
    for k, v in session_filters.items():
        if v:
            query = query.filter(session.model.__dict__[k].in_(session_filters[k]))

    if latitude and longitude:
        km_distance = 10
        latitude = int(latitude)
        longitude = int(longitude)
        query = db.query(session.model).from_statement(
            text(
                f"SELECT * FROM Session WHERE acos(sin(radians({latitude})) * sin(radians(lat)) + "
                f"cos(radians({latitude})) * cos(radians(lat)) * cos(radians(lon) - radians(({longitude})))) * 6373 <= {km_distance}"
                f" LIMIT {limit} OFFSET {skip};"
            )
        )
        return query.all()

    sessions = query.offset(skip).limit(limit).all()
    return sessions
