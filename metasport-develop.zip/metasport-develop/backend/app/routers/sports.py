# -*- coding: utf-8 -*-
# !/usr/bin/python3

# Python standard dependencies
from typing import List

# External
from sqlalchemy.orm import Session
from fastapi import Depends
from fastapi import HTTPException
from fastapi import APIRouter

from app.routers.router import get_db
from app.crud.sports import sport
from app import models
from app import schemas


router = APIRouter()


@router.post("/", response_model=schemas.Sport)
def create_sport(sport_create: schemas.SportCreate, db: Session = Depends(get_db)):
    return sport.create(db, obj_in=sport_create)


@router.put("/{sport_id}", response_model=schemas.Sport)
def update_sport(
    sport_id: int,
    sport_update: schemas.SportUpdate,
    db: Session = Depends(get_db),
):
    db_sport = sport.get(db, id=sport_id)
    if db_sport is None:
        raise HTTPException(status_code=404, detail="Sport not found")
    return sport.update(db, db_obj=db_sport, obj_in=sport_update)


@router.get("/{sport_id}", response_model=schemas.Sport)
def read_sport(sport_id: int, db: Session = Depends(get_db)):
    db_sport = sport.get(db, id=sport_id)
    if db_sport is None:
        raise HTTPException(status_code=404, detail="Sport not found")
    return db_sport


@router.delete("/{sport_id}", status_code=200)
def delete_sport(sport_id: int, db: Session = Depends(get_db)):
    db_sport = sport.get(db, id=sport_id)
    if db_sport is None:
        raise HTTPException(status_code=404, detail="Sport not found")
    sport.remove(db, id=sport_id)


@router.get("/", response_model=List[schemas.Sport])
def read_sports(skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    sports_list = sport.get_multi(db, skip=skip, limit=limit)
    return sports_list
