# -*- coding: utf-8 -*-
# !/usr/bin/python3

import enum

from sqlalchemy.types import ARRAY
from sqlalchemy import (
    Boolean,
    Column,
    ForeignKey,
    Integer,
    String,
    DateTime,
    Enum,
    Float,
)
from sqlalchemy.orm import relationship

from app.database import Base


class SessionLevel(str, enum.Enum):
    begginer = 1
    advanced = 2
    expert = 3


class Session(Base):
    __tablename__ = "session"

    id = Column(Integer, primary_key=True, index=True)

    user_id = Column(String)

    start = Column(DateTime)
    end = Column(DateTime)
    indoor = Column(Boolean)
    level = Column(Enum(SessionLevel))
    location_name = Column(String)
    max_participants = Column(Integer)
    description = Column(String)
    participants_ids = Column(
        ARRAY(String, as_tuple=False, dimensions=None, zero_indexes=False)
    )

    lat = Column(Float)
    lon = Column(Float)

    created_at = Column(DateTime)
    updated_at = Column(DateTime)
    deleted_at = Column(DateTime)

    # Relationships
    sport_id = Column(Integer, ForeignKey("sport.id"))
    sport = relationship("Sport")


class Sport(Base):
    __tablename__ = "sport"

    id = Column(Integer, primary_key=True, index=True)

    name = Column(String, index=True, unique=True)
