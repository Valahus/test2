from app.database import engine, Base

from app.database import SessionLocal
from app.crud.sports import sport as sport_crud
from app.schemas import SportCreate
from app.models import Sport


def create_sports():
    db = SessionLocal()
    if db.query(Sport).count() == 0:
        sports = [
            "soccer",
            "basketball",
            "tennis",
            "baseball",
            "golf",
            "running",
            "volleyball",
            "badminton",
            "swimming",
            "boxing",
            "table tennis",
            "skiing",
            "ice skating",
            "roller skating",
            "cricket",
            "rugby",
            "pool",
            "darts",
            "football",
            "bowling",
            "ice hockey",
            "surfing",
            "karate",
            "horse racing",
            "snowboarding",
            "skateboarding",
            "cycling",
            "archery",
            "fishing",
            "gymnastics",
            "figure skating",
            "rock climbing",
            "sumo wrestling",
            "taekwondo",
            "fencing",
            "water skiing",
            "jet skiing",
            "weight lifting",
            "scuba diving",
            "judo",
            "wind surfing",
            "kickboxing",
            "sky diving",
            "hang gliding",
            "bungee jumping",
        ]
        Base.metadata.create_all(bind=engine)
        for sport in sports:
            sport_create = SportCreate(name=sport)
            sport_crud.create(db, obj_in=sport_create)


def create_if_not_exist():
    Base.metadata.create_all(bind=engine)
    create_sports()
