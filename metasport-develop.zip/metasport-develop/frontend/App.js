import React, { useEffect, useState } from 'react';

import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import FontAwesome5 from 'react-native-vector-icons/FontAwesome5';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';

import { auth } from './src/firebase/config';
import { SubscribeForm } from './src/screens/SubscribeForm';
import LoadingSpinner from './src/components/LoadingSpinner.js';
import { Login, Home, Register, CreateSession, SessionDetails, Profile } from './src/screens';
import './src/utils/globals';

const Tab = createBottomTabNavigator();
const Stack = createStackNavigator();

export default function App() {
    const [loading, setLoading] = useState(true);
    const [user, setUser] = useState(null);

    useEffect(() => {
        auth.onAuthStateChanged((newUser) => {
            if (newUser) setUser(newUser);
            else setUser(null);
            setLoading(false);
        });
    }, []);

    function HomeTabs() {
        return (
            <Tab.Navigator
                screenOptions={{
                    headerShown: false,
                    tabBarShowLabel: false,
                    tabBarStyle: [
                        {
                            display: 'flex',
                            backgroundColor: 'rgba(216, 216, 216, 1)',
                        },
                        null,
                    ],
                }}
            >
                <Tab.Screen
                    name='Home'
                    options={{
                        tabBarActiveTintColor: '#34ace4',
                        tabBarIcon: ({ color, size }) => (
                            <FontAwesome5
                                style={{ marginRight: 5 }}
                                color='black'
                                name='home'
                                size={size}
                            />
                        ),
                    }}
                >
                    {(props) => <Home {...props} extraData={user} />}
                </Tab.Screen>
                <Tab.Screen
                    name='CreateSession'
                    options={{
                        tabBarActiveTintColor: '#34ace4',
                        tabBarIcon: ({ color, size }) => (
                            <FontAwesome5
                                style={{ marginRight: 5 }}
                                color='black'
                                name='plus-square'
                                size={size}
                            />
                        ),
                    }}
                >
                    {(props) => <CreateSession {...props} extraData={user} />}
                </Tab.Screen>
                <Tab.Screen
                    name='Profile'
                    options={{
                        tabBarActiveTintColor: '#34ace4',
                        tabBarIcon: ({ color, size }) => (
                            <FontAwesome5
                                style={{ marginRight: 5 }}
                                color='black'
                                name='user'
                                size={size}
                            />
                        ),
                    }}
                >
                    {(props) => <Profile {...props} extraData={user} />}
                </Tab.Screen>
                <Tab.Screen
                    name='SessionDetails'
                    component={SessionDetails}
                    options={{
                        tabBarButton: () => null,
                        tabBarVisible: false,
                    }}
                />
                <Tab.Screen
                    name='SubscribeForm'
                    component={SubscribeForm}
                    options={{
                        tabBarButton: () => null,
                        tabBarVisible: false,
                    }}
                />
            </Tab.Navigator>
        );
    }

    if (loading) return <LoadingSpinner />;

    return (
        <NavigationContainer>
            <Stack.Navigator
                screenOptions={{
                    headerShown: false,
                }}
            >
                {user !== null ? (
                    <Stack.Screen name='HomeTabs' component={HomeTabs} />
                ) : (
                    <>
                        <Stack.Screen name='Login' component={Login} />
                        <Stack.Screen name='Registration' component={Register} />
                        <Stack.Screen name='Profile' component={Profile} />
                    </>
                )}
            </Stack.Navigator>
        </NavigationContainer>
    );
}
