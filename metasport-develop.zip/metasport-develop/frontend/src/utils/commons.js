import moment from 'moment';

import Ionicons from 'react-native-vector-icons/Ionicons';
import Fontisto from 'react-native-vector-icons/Fontisto';
import AntDesign from 'react-native-vector-icons/AntDesign';
import Foundation from 'react-native-vector-icons/Foundation';
import FontAwesome5 from 'react-native-vector-icons/FontAwesome5';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';

export const getDaysUntilSessionSentence = function (sessionStart) {
    return moment(sessionStart).fromNow();
};

export const levelsDetails = {
    1: { color: '#4eaef2', name: 'beginner' },
    2: { color: '#5a30e6', name: 'advanced' },
    3: { color: '#ed4328', name: 'expert' },
};

export const getMaterialIcon = function (name, size = 25, color = 'black', style = {}) {
    return <MaterialIcons style={style} color={color} name={name} size={size} />;
};

export const getIonicon = function (name, size = 25, color = 'black', style = {}) {
    return <Ionicons style={style} color={color} name={name} size={size} />;
};

export const getMaterialCommunityIcon = function (name, size = 25, color = 'black', style = {}) {
    return <MaterialCommunityIcons style={style} color={color} name={name} size={size} />;
};

export const getFontAwesome5Icon = function (name, size = 25, color = 'black', style = {}) {
    return <FontAwesome5 style={style} color={color} name={name} size={size} />;
};

export const sportsIcons = {
    soccer: getMaterialIcon('sports-soccer'),
    basketball: getIonicon('basketball-outline'),
    tennis: getIonicon('tennisball-outline'),
    baseball: getIonicon('baseball-outline'),
    golf: getMaterialCommunityIcon('golf-tee'),
    running: getFontAwesome5Icon('running'),
    volleyball: getMaterialCommunityIcon('volleyball'),
    badminton: getMaterialCommunityIcon('badminton'),
    swimming: getMaterialCommunityIcon('swim'),
    boxing: getMaterialCommunityIcon('boxing-glove'),
    'table tennis': getFontAwesome5Icon('table-tennis'),
    skiing: getFontAwesome5Icon('skiing'),
    'ice skating': getMaterialCommunityIcon('skate'),
    'roller skating': getMaterialCommunityIcon('roller-skate'),
    cricket: getMaterialCommunityIcon('cricket'),
    rugby: getMaterialCommunityIcon('rugby'),
    // "pool": ,
    // "darts": ,
    football: getFontAwesome5Icon('football-ball'),
    bowling: getFontAwesome5Icon('bowling-ball'),
    'ice hockey': getMaterialCommunityIcon('hockey-sticks'),
    surfing: getMaterialCommunityIcon('surfing'),
    karate: getMaterialCommunityIcon('karate'),
    'horse racing': getMaterialCommunityIcon('horse-human'),
    snowboarding: getMaterialCommunityIcon('snowboard'),
    skateboarding: getMaterialCommunityIcon('skateboarding'),
    cycling: getMaterialCommunityIcon('bicycle'),
    // "archery": ,
    fishing: getMaterialCommunityIcon('fish'),
    // "gymnastics": ,
    // "figure skating": ,
    // "rock climbing": ,
    // "sumo wrestling": ,
    taekwondo: getMaterialCommunityIcon('karate'),
    // "fencing": ,
    // "water skiing": ,
    // "jet skiing": ,
    'weight lifting': getMaterialCommunityIcon('weight-lifter'),
    // "scuba diving": ,
    // "judo": ,
    // "wind surfing": ,
    // "kickboxing": ,
    // "sky diving": ,
    // "hang gliding": ,
    // "bungee jumping": ,
};
