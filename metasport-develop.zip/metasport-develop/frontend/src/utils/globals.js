global.backendUrl = 'http://XXX.XXX.X.XX:8888';
