import { StyleSheet } from 'react-native';

/* Metasport palette */
const nileBlue = '#173554';
const pictonBlue = '#34ACE4';
const seagull = '#88CFED';

export const mainStyles = StyleSheet.create({
    authContainer: {
        flex: 1,
        alignItems: 'center',
    },
    container: {
        paddingLeft: 20,
        paddingRight: 20,
        flex: 1,
    },
    logo: {
        flex: 1,
        height: 240,
        width: 240,
        alignSelf: 'center',
        margin: 30,
    },
    input: {
        height: 48,
        borderRadius: 5,
        overflow: 'hidden',
        backgroundColor: 'white',
        marginTop: 10,
        marginBottom: 10,
        marginLeft: 30,
        marginRight: 30,
        paddingLeft: 16,
    },
    footerView: {
        flex: 1,
        alignItems: 'center',
        marginTop: 20,
    },
    text: {
        fontSize: 16,
    },
    footerText: {
        fontSize: 16,
        color: '#2e2e2d',
    },
    footerLink: {
        color: '#34ace4',
        fontWeight: 'bold',
        fontSize: 16,
    },
    card: {
        marginTop: 12,
        padding: 1,
        elevation: 1,
        border: '0.2px grey solid',
        borderRadius: 10,
    },
    headerCard: {
        elevation: 0,
    },
    cardContent: {
        flexDirection: 'row',
        flexWrap: 'wrap',
    },
    cardLabels: {
        paddingVertical: 3,
        paddingHorizontal: 15,
        borderRadius: 25,
        margin: 2,
    },
    filtersCard: {
        height: '100%',
        borderRadius: 0,
        padding: 10,
        marginLeft: 50,
    },
    popupCard: {
        width: '80%',
        alignSelf: 'center',
        minHeight: '20%',
        borderRadius: 15,
        padding: 10,
    },
    textShrink: {
        flexShrink: 1,
    },
    buttonPicker: {
        backgroundColor: 'white',
        width: '100%',
        margin: 10,
        height: 30,
        borderRadius: 5,
        alignItems: 'center',
        justifyContent: 'center',
        alignSelf: 'center',
    },
    buttonPickerText: {
        color: 'black',
        fontSize: 12,
        fontWeight: 'bold',
    },
    subContainer: {
        marginTop: 60,
        paddingLeft: 20,
        paddingRight: 20,
    },
    subContext: {
        flexDirection: 'column',
    },
    basicCard: {
        margin: 15,
        backgroundColor: seagull,
        borderRadius: 10,
    },
    premiumCard: {
        margin: 15,
        backgroundColor: pictonBlue,
        borderRadius: 10,
    },
    partnerCard: {
        margin: 15,
        backgroundColor: nileBlue,
        borderRadius: 10,
    },
    titleText: {
        textAlign: 'center',
        fontSize: 30,
        marginBottom: 15,
        color: '#FFFFFF',
    },
    titlePrice: {
        textAlign: 'center',
        fontSize: 25,
        marginBottom: 30,
        color: '#FFFFFF',
    },
    textSubscribe: {
        color: '#FFFFFF',
        marginBottom: 10,
        fontSize: 15,
    },
});
