import React, { useEffect } from 'react';

import Modal from 'react-native-modal';
import { Text, View, TextInput } from 'react-native';
import { Card } from 'react-native-paper';

import { CustomButton } from './CustomButton';
import { mainStyles } from '../styles/mainStyles';

const IPConfig = ({ popupVisible, setPopupVisible, ipAddr, setIpAddr, onClose }) => {
    useEffect(() => {}, [popupVisible]);

    return (
        <Modal
            isVisible={popupVisible}
            animationIn='slideInRight'
            animationOut='slideOutRight'
            style={{ margin: 0 }}
        >
            <Card style={mainStyles.popupCard}>
                <View
                    style={{
                        flex: 1,
                        padding: 10,
                        flexDirection: 'column',
                        justifyContent: 'space-between',
                    }}
                >
                    <Text style={[mainStyles.textShrink, { fontSize: 18 }]}>Backend IP addr</Text>
                    <TextInput
                        placeholder='192.XX.XX.XX'
                        value={ipAddr}
                        onChangeText={(text) => setIpAddr(text)}
                        style={{ borderWidth: 1, borderColor: '#EDEDED', marginTop: 5 }}
                        editable
                        maxLength={30}
                        underlineColorAndroid='transparent'
                        autoCapitalize='none'
                    />
                    <View
                        style={{
                            flexDirection: 'row',
                            justifyContent: 'space-between',
                            width: '100%',
                        }}
                    >
                        <CustomButton
                            text='Cancel'
                            width='30%'
                            onPress={() => {
                                setPopupVisible(false);
                            }}
                            colors={['rgba(216,27,96,1)', 'rgba(237,107,154,1)']}
                        />
                        <CustomButton
                            text='OK'
                            width='30%'
                            onPress={() => {
                                setPopupVisible(false);
                                if (onClose) onClose();
                            }}
                        />
                    </View>
                </View>
            </Card>
        </Modal>
    );
};

export { IPConfig };
