import React, { useEffect, useState } from 'react';

import AntDesign from 'react-native-vector-icons/AntDesign';
import { MultiSelect, Dropdown } from 'react-native-element-dropdown';
import { StatusBar, StyleSheet, Text, View, TouchableOpacity } from 'react-native';

const LevelsPicker = ({ selectedLevels, setSelectedLevels, isMulti }) => {
    const [selected, setSelected] = useState(
        selectedLevels.length > 0 ? selectedLevels.map((selectedLevel) => selectedLevel.value) : []
    );

    const levels = [
        { label: 'beginner', value: 1 },
        { label: 'advanced', value: 2 },
        { label: 'expert', value: 3 },
    ];

    const renderDataItem = (item) => {
        return (
            <View style={styles.item}>
                <Text style={styles.selectedTextStyle}>{item.label}</Text>
            </View>
        );
    };

    useEffect(() => {
        let tmpSelectedLevels = [];
        selected.forEach((s) => {
            tmpSelectedLevels.push(levels.find((x) => x.value === s));
        });
        setSelectedLevels(tmpSelectedLevels);
    }, [selected]);

    if (isMulti === true)
        return (
            <View>
                <MultiSelect
                    style={styles.dropdown}
                    placeholderStyle={styles.placeholderStyle}
                    selectedTextStyle={styles.selectedTextStyle}
                    inputSearchStyle={styles.inputSearchStyle}
                    iconStyle={styles.iconStyle}
                    data={levels}
                    labelField='label'
                    valueField='value'
                    placeholder='Levels'
                    value={selected}
                    onChange={(item) => {
                        setSelected(item);
                    }}
                    renderItem={renderDataItem}
                    renderSelectedItem={(item, unSelect) => (
                        <TouchableOpacity onPress={() => unSelect && unSelect(item)}>
                            <View style={styles.selectedStyle}>
                                <Text style={styles.textSelectedStyle}>{item.label}</Text>
                                <AntDesign color='black' name='delete' size={17} />
                            </View>
                        </TouchableOpacity>
                    )}
                />
                <StatusBar />
            </View>
        );

    return (
        <Dropdown
            style={styles.dropdown}
            placeholderStyle={styles.placeholderStyle}
            selectedTextStyle={styles.selectedTextStyle}
            inputSearchStyle={styles.inputSearchStyle}
            iconStyle={styles.iconStyle}
            data={levels}
            maxHeight={300}
            labelField='label'
            valueField='value'
            placeholder='Select level'
            value={selectedLevels.length > 0 ? selectedLevels[0] : null}
            onChange={(item) => {
                setSelected([item.value]);
            }}
        />
    );
};

const styles = StyleSheet.create({
    dropdown: {
        height: 50,
        backgroundColor: 'white',
        borderRadius: 12,
        padding: 12,
        shadowColor: '#000',
        shadowOffset: {
            width: 0,
            height: 1,
        },
        shadowOpacity: 0.2,
        shadowRadius: 1.41,

        elevation: 2,
    },
    placeholderStyle: {
        fontSize: 16,
    },
    selectedTextStyle: {
        fontSize: 14,
    },
    iconStyle: {
        width: 20,
        height: 20,
    },
    inputSearchStyle: {
        height: 40,
        fontSize: 16,
    },
    icon: {
        marginRight: 5,
    },
    item: {
        padding: 17,
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
    },
    selectedStyle: {
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 14,
        backgroundColor: 'white',
        shadowColor: '#000',
        marginTop: 8,
        marginRight: 12,
        paddingHorizontal: 12,
        paddingVertical: 8,
        shadowOffset: {
            width: 0,
            height: 1,
        },
        shadowOpacity: 0.2,
        shadowRadius: 1.41,

        elevation: 2,
    },
    textSelectedStyle: {
        marginRight: 5,
        fontSize: 16,
    },
});

export { LevelsPicker };
