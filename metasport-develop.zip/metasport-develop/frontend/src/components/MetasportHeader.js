import React from 'react';
import { View } from 'react-native';
import { Avatar, Text } from 'react-native-paper';

const MetasportHeader = () => {
    return (
        <View
            style={{
                marginTop: 20,
                flexDirection: 'row',
                justifyContent: 'center',
                alignItems: 'center',
            }}
        >
            <Avatar.Image
                size={60}
                style={{ backgroundColor: 'transparent' }}
                source={require('../../assets/trademark/logo-square-transparent-bg.png')}
            />
            <Text
                style={{
                    fontSize: 25,
                    textAlign: 'center',
                    fontWeight: 'bold',
                }}
            >
                METASPORT
            </Text>
        </View>
    );
};

export { MetasportHeader as MetasportHeader };
