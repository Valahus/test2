import React from 'react';
import { TextInput } from 'react-native';
import { mainStyles } from '../styles/mainStyles';

const GreenTextInput = (props) => {
    return (
        <TextInput
            {...props}
            style={mainStyles.input}
            underlineColorAndroid='transparent'
            autoCapitalize='none'
        />
    );
};

export { GreenTextInput };
