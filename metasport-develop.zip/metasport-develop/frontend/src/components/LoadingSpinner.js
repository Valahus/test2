import React, { Component } from 'react';
import { ActivityIndicator, View, StyleSheet } from 'react-native';
import { Avatar } from 'react-native-paper';

class LoadingSpinner extends Component {
    state = { animating: true };
    closeActivityIndicator = () =>
        setTimeout(
            () =>
                this.setState({
                    animating: false,
                }),
            60000
        );
    componentDidMount = () => this.closeActivityIndicator();
    render() {
        const animating = this.state.animating;
        return (
            <View style={styles.container}>
                <Avatar.Image
                    size={100}
                    style={styles.logo}
                    source={require('../../assets/trademark/logo-square-transparent-bg.png')}
                />
                <ActivityIndicator
                    animating={animating}
                    color='#173554'
                    size='large'
                    style={styles.activityIndicator}
                />
            </View>
        );
    }
}
export default LoadingSpinner;
const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        marginTop: 50,
    },
    activityIndicator: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        height: 70,
    },
    logo: {
        flex: 1,
        position: 'absolute',
        alignItems: 'center',
        backgroundColor: 'transparent',
        marginTop: -150,
    },
});
