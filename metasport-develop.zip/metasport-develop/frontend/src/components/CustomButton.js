import React from 'react';
import { Text, TouchableOpacity } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { mainStyles } from '../styles/mainStyles';

const CustomButton = ({ width, text, onPress, colors }) => {
    return (
        <LinearGradient
            start={{ x: 0, y: 0.5 }}
            end={{ x: 1, y: 0.5 }}
            colors={colors || ['rgba(37,249,245,1)', 'rgba(8,70,218,1)']}
            style={{
                borderRadius: 25,
                width: width || '80%',
                alignSelf: 'center',
            }}
        >
            <TouchableOpacity
                style={{
                    padding: 12,
                    width: '100%',
                    justifyContent: 'center',
                    alignItems: 'center',
                }}
                onPress={onPress}
            >
                <Text
                    style={[
                        mainStyles.textShrink,
                        { color: 'white', fontSize: 15, fontWeight: 'bold' },
                    ]}
                >
                    {text}
                </Text>
            </TouchableOpacity>
        </LinearGradient>
    );
};

export { CustomButton };
