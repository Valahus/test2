import React, { useEffect } from 'react';

import Modal from 'react-native-modal';
import { Text, View } from 'react-native';
import { Card } from 'react-native-paper';

import { CustomButton } from './CustomButton';
import { mainStyles } from '../styles/mainStyles';

const CustomPopup = ({ text, popupVisible, setPopupVisible, onClose, cancelButton }) => {
    useEffect(() => {}, [popupVisible]);

    return (
        <Modal
            isVisible={popupVisible}
            animationIn='slideInDown'
            animationOut='slideOutDown'
            style={{ margin: 0 }}
        >
            <Card style={mainStyles.popupCard}>
                <View
                    style={{
                        flex: 1,
                        padding: 10,
                        flexDirection: 'column',
                        justifyContent: 'space-between',
                    }}
                >
                    <Text style={[mainStyles.textShrink, { fontSize: 18 }]}>{text}</Text>
                    <View
                        style={{
                            flexDirection: 'row',
                            justifyContent: 'space-between',
                            width: '100%',
                        }}
                    >
                        {cancelButton === true ? (
                            <CustomButton
                                text='Cancel'
                                width='30%'
                                onPress={() => {
                                    setPopupVisible(false);
                                }}
                                colors={['rgba(216,27,96,1)', 'rgba(237,107,154,1)']}
                            />
                        ) : null}
                        <CustomButton
                            text='OK'
                            width={cancelButton === true ? '30%' : '100%'}
                            onPress={() => {
                                setPopupVisible(false);
                                if (onClose) onClose();
                            }}
                        />
                    </View>
                </View>
            </Card>
        </Modal>
    );
};

export { CustomPopup };
