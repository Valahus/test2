import React, { useState } from 'react';
import { View, Text, TouchableOpacity } from 'react-native';
import { mainStyles } from '../styles/mainStyles';
import DateTimePicker from '@react-native-community/datetimepicker';
import { format } from 'date-fns';

const DatePickerCustom = ({ date, setDate }) => {
    const [show, setShow] = useState(false);

    const onChange = (event) => {
        setShow(false);
        setDate(new Date(event.nativeEvent.timestamp));
    };

    return (
        <View style={{ marginRight: 10 }}>
            <TouchableOpacity style={mainStyles.buttonPicker} onPress={() => setShow(true)}>
                <Text style={mainStyles.buttonPickerText}>{`Date: ${format(
                    date,
                    'MM/dd/yy'
                )}`}</Text>
            </TouchableOpacity>
            {show && (
                <DateTimePicker
                    testID='dateTimePicker'
                    value={date}
                    mode='date'
                    is24Hour={true}
                    display='default'
                    onChange={onChange}
                />
            )}
        </View>
    );
};

export default DatePickerCustom;
