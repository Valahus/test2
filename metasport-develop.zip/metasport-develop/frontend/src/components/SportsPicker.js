import axios from 'axios';
import React, { useEffect, useState } from 'react';

import AntDesign from 'react-native-vector-icons/AntDesign';
import { MultiSelect, Dropdown } from 'react-native-element-dropdown';
import { StatusBar, StyleSheet, Text, View, TouchableOpacity } from 'react-native';

const SportsPicker = ({ selectedSports, setSelectedSports, isMulti }) => {
    const [sports, setSports] = useState([]);
    const [selected, setSelected] = useState(
        selectedSports.length > 0 ? selectedSports.map((selectedSport) => selectedSport.id) : []
    );

    const renderDataItem = (item) => {
        return (
            <View style={styles.item}>
                <Text style={styles.selectedTextStyle}>{item.label}</Text>
            </View>
        );
    };

    useEffect(() => {
        axios.get(`${global.backendUrl}/sports`).then((res) => {
            const sports = res.data;
            setSports(
                sports.map((sport) => {
                    return { label: sport.name, id: sport.id };
                })
            );
        });
    }, []);

    useEffect(() => {
        if (sports.length === 0) return;
        let tmpSelectedSports = [];
        selected.forEach((s) => {
            tmpSelectedSports.push(sports.find((x) => x.id === s));
        });
        setSelectedSports(tmpSelectedSports);
    }, [selected]);

    if (isMulti === true)
        return (
            <View style={{ marginBottom: 15 }}>
                <MultiSelect
                    style={styles.dropdown}
                    placeholderStyle={styles.placeholderStyle}
                    selectedTextStyle={styles.selectedTextStyle}
                    inputSearchStyle={styles.inputSearchStyle}
                    iconStyle={styles.iconStyle}
                    data={sports}
                    labelField='label'
                    valueField='id'
                    placeholder='Sports'
                    value={selected}
                    search
                    searchPlaceholder='Search sports...'
                    onChange={(item) => {
                        setSelected(item);
                    }}
                    renderItem={renderDataItem}
                    renderSelectedItem={(item, unSelect) => (
                        <TouchableOpacity onPress={() => unSelect && unSelect(item)}>
                            <View style={styles.selectedStyle}>
                                <Text style={styles.textSelectedStyle}>{item.label}</Text>
                                <AntDesign color='black' name='delete' size={17} />
                            </View>
                        </TouchableOpacity>
                    )}
                />
                <StatusBar />
            </View>
        );
    return (
        <Dropdown
            style={styles.dropdown}
            placeholderStyle={styles.placeholderStyle}
            selectedTextStyle={styles.selectedTextStyle}
            inputSearchStyle={styles.inputSearchStyle}
            iconStyle={styles.iconStyle}
            data={sports}
            search
            maxHeight={300}
            labelField='label'
            valueField='id'
            placeholder='Select sport'
            searchPlaceholder='Search sports...'
            value={selectedSports.length > 0 ? selectedSports[0] : null}
            onChange={(item) => {
                setSelectedSports([item]);
            }}
        />
    );
};

const styles = StyleSheet.create({
    dropdown: {
        marginBottom: 15,
        height: 50,
        backgroundColor: 'white',
        borderRadius: 12,
        padding: 12,
        shadowColor: '#000',
        shadowOffset: {
            width: 0,
            height: 1,
        },
        shadowOpacity: 0.2,
        shadowRadius: 1.41,

        elevation: 2,
    },
    placeholderStyle: {
        fontSize: 16,
    },
    selectedTextStyle: {
        fontSize: 14,
    },
    iconStyle: {
        width: 20,
        height: 20,
    },
    inputSearchStyle: {
        height: 40,
        fontSize: 16,
    },
    icon: {
        marginRight: 5,
    },
    item: {
        padding: 17,
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
    },
    selectedStyle: {
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 14,
        backgroundColor: 'white',
        shadowColor: '#000',
        marginTop: 8,
        marginRight: 12,
        paddingHorizontal: 12,
        paddingVertical: 8,
        shadowOffset: {
            width: 0,
            height: 1,
        },
        shadowOpacity: 0.2,
        shadowRadius: 1.41,

        elevation: 2,
    },
    textSelectedStyle: {
        marginRight: 5,
        fontSize: 16,
    },
});

export { SportsPicker };
