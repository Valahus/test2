import React, { useState } from 'react';
import { View, Text, TouchableOpacity } from 'react-native';
import { mainStyles } from '../styles/mainStyles';
import DateTimePicker from '@react-native-community/datetimepicker';
import { format } from 'date-fns';

const TimePickerCustom = ({ time, setTime }) => {
    const [show, setShow] = useState(false);

    const onChange = (event) => {
        setShow(false);
        setTime(new Date(event.nativeEvent.timestamp));
    };

    const formattedTime = (timestampFromEvent) => {
        let timestamp = new Date(timestampFromEvent);
        let hours = timestamp.getHours();
        let minutes = timestamp.getMinutes();
        if (hours < 10) {
            hours = '0' + hours;
        }
        if (minutes < 10) {
            minutes = '0' + minutes;
        }
        const getTime = hours + ':' + minutes;
        return hours + ':' + minutes;
    };

    return (
        <View>
            <TouchableOpacity style={mainStyles.buttonPicker} onPress={() => setShow(true)}>
                <Text style={mainStyles.buttonPickerText}>{`Time: ${format(time, 'HH:mm')}`}</Text>
            </TouchableOpacity>
            {show && (
                <DateTimePicker
                    testID='dateTimePicker'
                    value={time}
                    mode='time'
                    is24Hour={true}
                    display='default'
                    onChange={onChange}
                />
            )}
        </View>
    );
};

export default TimePickerCustom;
