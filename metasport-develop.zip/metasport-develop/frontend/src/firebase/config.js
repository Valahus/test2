import firebase from 'firebase/compat/app';
import 'firebase/compat/auth';
import 'firebase/compat/firestore';
import * as geofirestore from 'geofirestore';

const firebaseConfig = {
    apiKey: 'AIzaSyCvCQQ7sb8hT91j74_uR3PeBhFUrHNifTk',
    authDomain: 'code-camp-186.firebaseapp.com',
    projectId: 'code-camp-186',
    storageBucket: 'code-camp-186.appspot.com',
    messagingSenderId: '357859856460',
    databaseURL: 'https://code-camp-168.firebaseio.com',
    appId: '1:357859856460:web:a07934b13d32acd08aa4e9',
};

const app = firebase.initializeApp(firebaseConfig);

export const auth = firebase.auth();
