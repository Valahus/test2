import React from 'react';

import firebase from 'firebase/compat/app';
import { View, Text } from 'react-native';
import { CustomButton } from '../components/CustomButton';
import FontAwesome5 from 'react-native-vector-icons/FontAwesome5';

import { auth } from '../firebase/config';
import { mainStyles } from '../styles/mainStyles';
import { ScrollView } from 'react-native-gesture-handler';

const Profile = ({ props, navigation }) => {
    var user = firebase.auth().currentUser;

    if (!user) return <></>;

    const userProps = [
        { icon: 'location', prop: user.location },
        { icon: 'pen', prop: user.description },
        { icon: 'envelope', prop: user.email },
        { icon: 'birthday-cake', prop: user.birthdate },
    ];

    return (
        <ScrollView style={mainStyles.container}>
            <View
                style={{
                    flexDirection: 'column',
                    justifyContent: 'center',
                    alignItems: 'center',
                    marginTop: 45,
                }}
            >
                <FontAwesome5 color='black' name='user' size={125} />
                <Text>{user.displayName} </Text>

                {userProps.map((value, index) => {
                    if (!value.prop) return;
                    return (
                        <View
                            key={index}
                            style={{
                                width: '80%',
                                flexDirection: 'row',
                                justifyContent: 'center',
                                alignItems: 'center',
                            }}
                        >
                            <FontAwesome5
                                style={{ marginRight: 5 }}
                                color='black'
                                name={value.icon}
                                size={25}
                            />
                            <Text>{value.prop}</Text>
                        </View>
                    );
                })}
            </View>
            <View style={{ marginTop: 15 }}>
                <CustomButton
                    text={'Subscribe'}
                    onPress={() => navigation.navigate('SubscribeForm')}                    
                />
            </View>
            <View style={{ marginTop: 15 }}>
                <CustomButton
                    text={'Log out'}
                    onPress={() => auth.signOut()}
                    colors={['rgba(216,27,96,1)', 'rgba(237,107,154,1)']}
                />
            </View>
        </ScrollView>
    );
};

export { Profile };
