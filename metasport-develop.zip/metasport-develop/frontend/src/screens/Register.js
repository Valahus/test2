import React, { useState } from 'react';
import { Image, Text, View } from 'react-native';
import { createUserWithEmailAndPassword } from 'firebase/auth';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';

import { auth } from '../firebase/config';
import { mainStyles } from '../styles/mainStyles';
import { CustomButton } from '../components/CustomButton';
import { GreenTextInput } from '../components/GreenTextInput';
import { CustomPopup } from '../components/CustomPopup';

const Register = ({ navigation }) => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');

    const [errorPopupVisible, setErrorPopupVisible] = useState(false);
    const [errorPopupMessage, setErrorPopupMessage] = useState('');
    const errorMessagesByCode = {
        'auth/invalid-email': 'Invalid E-mail',
        'auth/internal-error': 'An error occured',
        'auth/weak-password': 'Password is too weak',
        'auth/email-already-in-use': 'This E-mail is already in use, please log in',
    };

    const onFooterLinkPress = () => {
        navigation.navigate('Login');
    };

    const onRegisterPress = () => {
        if (!password || !confirmPassword) {
            setErrorPopupMessage('Password must be set');
            setErrorPopupVisible(true);
            return;
        }
        if (password !== confirmPassword) {
            setErrorPopupMessage("Passwords don't match");
            setErrorPopupVisible(true);
            return;
        }

        createUserWithEmailAndPassword(auth, email, password)
            .then((response) => {
                console.debug(`User account created and signed in : ${JSON.stringify(response)}`);
            })
            .catch((error) => {
                setErrorPopupMessage(errorMessagesByCode[error.code] || error.code);
                setErrorPopupVisible(true);
            });
    };

    return (
        <View style={mainStyles.authContainer}>
            <KeyboardAwareScrollView
                style={{ flex: 1, width: '100%' }}
                keyboardShouldPersistTaps='always'
            >
                <Image
                    style={mainStyles.logo}
                    source={require('../../assets/trademark/logo-transparent-bg.png')}
                />
                <GreenTextInput
                    placeholder='E-mail'
                    onChangeText={(text) => setEmail(text)}
                    value={email}
                />
                <GreenTextInput
                    secureTextEntry
                    placeholder='Password'
                    onChangeText={(text) => setPassword(text)}
                    value={password}
                />
                <GreenTextInput
                    secureTextEntry
                    placeholder='Confirm Password'
                    onChangeText={(text) => setConfirmPassword(text)}
                    value={confirmPassword}
                />
                <CustomButton text={'Create account'} onPress={() => onRegisterPress()} />
                <View style={mainStyles.footerView}>
                    <Text style={mainStyles.footerText}>
                        Already got an account ?{' '}
                        <Text onPress={onFooterLinkPress} style={mainStyles.footerLink}>
                            Log in
                        </Text>
                    </Text>
                </View>
            </KeyboardAwareScrollView>

            <CustomPopup
                popupVisible={errorPopupVisible}
                setPopupVisible={setErrorPopupVisible}
                text={errorPopupMessage}
                cancelButton={false}
            />
        </View>
    );
};

export { Register };
