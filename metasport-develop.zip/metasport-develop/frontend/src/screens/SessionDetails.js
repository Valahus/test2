import axios from 'axios';
import React, { useEffect, useState } from 'react';

import { format } from 'date-fns';
import { Card } from 'react-native-paper';
import { Linking, Platform, ScrollView, Text, TouchableOpacity, View } from 'react-native';
import { useNavigation, useIsFocused } from '@react-navigation/native';

import Ionicons from 'react-native-vector-icons/Ionicons';
import Fontisto from 'react-native-vector-icons/Fontisto';
import AntDesign from 'react-native-vector-icons/AntDesign';
import Foundation from 'react-native-vector-icons/Foundation';
import FontAwesome5 from 'react-native-vector-icons/FontAwesome5';

import { levelsDetails, sportsIcons, getDaysUntilSessionSentence } from '../utils/commons';
import { mainStyles } from '../styles/mainStyles';
import { CustomPopup } from '../components/CustomPopup';
import { CustomButton } from '../components/CustomButton';

const SessionDetails = ({ props, route }) => {
    const navigation = useNavigation();
    const isFocused = useIsFocused();

    const [deletePopupVisible, setDeletePopupVisible] = useState(false);
    const [cancelPopupVisible, setCancelPopupVisible] = useState(false);

    const [session, setSession] = useState(null);
    const [sessionID, setSessionID] = useState(null);

    const collectSession = function () {
        axios.get(`${global.backendUrl}/sessions/${sessionID}`).then((res) => {
            const session = res.data;
            setSession(session);
        });
    };

    useEffect(() => {
        if (sessionID !== null) {
            if (sessionID !== route.params.session.id) collectSession();
            else setSession(route.params.session);
        }
    }, [sessionID]);

    useEffect(() => {
        if (isFocused === false) setSessionID(null);
        else setSessionID(route.params.session.id);
    }, [isFocused]);

    const enroll = function () {
        session.participants_ids.push(route.params.userID);
        axios
            .put(`${global.backendUrl}/sessions/${sessionID}`, session)
            .then((res) => {
                console.debug(res.data);
                navigation.navigate('Home', { refresh: false });
            })
            .catch((e) => {
                console.error(JSON.stringify(e));
            });
    };

    const cancelParticipation = function () {
        const index = session.participants_ids.indexOf(route.params.userID);
        if (index > -1) session.participants_ids.splice(index, 1);
        navigation.navigate('Home', { refresh: false });
    };

    const deleteSession = function () {
        axios
            .delete(`${global.backendUrl}/sessions/${sessionID}`)
            .then((res) => {
                console.debug(res.data);
                navigation.navigate('Home', { refresh: true });
            })
            .catch((e) => {
                console.error(JSON.stringify(e));
            });
    };

    const openGoogleMap = () => {
        const latitude = session.lat;
        const longitude = session.lon;
        const url = Platform.select({
            ios: `comgooglemaps://?center=${latitude},${longitude}&q=${latitude},${longitude}&zoom=14&views=traffic"`,
            android: `geo://?q=${latitude},${longitude}`,
        });
        Linking.canOpenURL(url)
            .then((supported) => {
                if (supported) {
                    return Linking.openURL(url);
                } else {
                    const browser_url = `https://www.google.de/maps/@${latitude},${longitude}`;
                    return Linking.openURL(browser_url);
                }
            })
            .catch(() => {
                if (Platform.OS === 'ios') {
                    Linking.openURL(`maps://?q=${latitude},${longitude}`);
                }
            });
    };

    const GetParticipationButton = function () {
        if (session.participants_ids.includes(route.params.userID)) {
            if (session.user_id === route.params.userID)
                return (
                    <>
                        <CustomButton
                            text={'Delete session'}
                            onPress={() => {
                                setDeletePopupVisible(true);
                            }}
                            colors={['rgba(216,27,96,1)', 'rgba(237,107,154,1)']}
                        />
                        <CustomPopup
                            popupVisible={deletePopupVisible}
                            setPopupVisible={setDeletePopupVisible}
                            text='Are you sure you want to delete this session ?'
                            onClose={deleteSession}
                            cancelButton={true}
                        />
                    </>
                );
            return (
                <>
                    <CustomButton
                        text={'Cancel participation'}
                        onPress={() => {
                            setCancelPopupVisible(true);
                        }}
                        colors={['rgba(216,27,96,1)', 'rgba(237,107,154,1)']}
                    />
                    <CustomPopup
                        popupVisible={cancelPopupVisible}
                        setPopupVisible={setCancelPopupVisible}
                        text='Are you sure you want to cancel your participation ?'
                        onClose={cancelParticipation}
                        cancelButton={true}
                    />
                </>
            );
        }

        if (session.participants_ids.length < session.max_participants)
            return <CustomButton text={'Join in'} onPress={() => enroll()} />;

        return <Text>Full session</Text>;
    };

    if (session === null) return <></>;
    return (
        <ScrollView style={mainStyles.container}>
            <Card style={{ marginTop: 45 }}>
                <View
                    style={{
                        flexDirection: 'row',
                        padding: 10,
                        justifyContent: 'space-between',
                    }}
                >
                    <Text style={{ fontSize: 20, fontWeight: 'bold' }}>
                        {sportsIcons[session.sport.name]} {session.sport.name}
                    </Text>

                    <Text
                        style={{
                            color: 'grey',
                            fontSize: 14,
                        }}
                    >
                        {getDaysUntilSessionSentence(session.start)}
                    </Text>
                </View>
                <Card.Content>
                    <View style={{ flexDirection: 'column' }}>
                        {session.description ? (
                            <View
                                style={{
                                    alignItems: 'center',
                                    flexDirection: 'row',
                                    marginTop: 15,
                                    marginBottom: 15,
                                }}
                            >
                                <FontAwesome5
                                    style={{ marginRight: 5 }}
                                    color='black'
                                    name='pencil-alt'
                                    size={25}
                                />
                                <Text style={{ flexShrink: 1 }}>{session.description}</Text>
                            </View>
                        ) : null}
                        <View
                            style={{
                                alignItems: 'center',
                                flexDirection: 'row',
                                marginTop: 15,
                                marginBottom: 15,
                            }}
                        >
                            <Fontisto
                                style={{ marginRight: 5 }}
                                color='black'
                                name='date'
                                size={25}
                            />
                            <Text>{format(new Date(session.start), 'MMMM do H:mma')}</Text>
                        </View>
                        <TouchableOpacity
                            onPress={() => openGoogleMap()}
                            style={{
                                alignItems: 'center',
                                flexDirection: 'row',
                                marginBottom: 15,
                            }}
                        >
                            <Ionicons
                                style={{ marginRight: 5 }}
                                color='#BA1E1E'
                                name='location'
                                size={25}
                            />
                            <Text style={{ flexShrink: 1 }}>{session.location_name}</Text>
                        </TouchableOpacity>
                        <View
                            style={{
                                alignItems: 'center',
                                flexDirection: 'row',
                                marginBottom: 15,
                            }}
                        >
                            <Foundation
                                style={{ marginRight: 5 }}
                                color='green'
                                name='trees'
                                size={25}
                            />
                            <Text>{session.indoor ? 'Indoor' : 'Outdoor'}</Text>
                        </View>
                        <View
                            style={{
                                alignItems: 'center',
                                flexDirection: 'row',
                                marginBottom: 15,
                            }}
                        >
                            <AntDesign
                                style={{ marginRight: 5 }}
                                color={levelsDetails[session.level].color}
                                name='dashboard'
                                size={25}
                            />
                            <Text>{levelsDetails[session.level].name}</Text>
                        </View>
                        <View
                            style={{
                                alignItems: 'center',
                                flexDirection: 'row',
                                marginBottom: 15,
                            }}
                        >
                            <FontAwesome5
                                style={{ marginRight: 5 }}
                                color='black'
                                name='users'
                                size={25}
                            />
                            {session.max_participants &&
                            session.participants_ids.length == session.max_participants ? (
                                <Text>full session</Text>
                            ) : (
                                session.max_participants && (
                                    <Text>
                                        {`${session.participants_ids.length}/${session.max_participants}`}
                                    </Text>
                                )
                            )}
                        </View>
                    </View>
                </Card.Content>
            </Card>
            <View style={{ marginTop: 15 }}>
                {session.max_participants && GetParticipationButton()}
            </View>
        </ScrollView>
    );
};

export { SessionDetails };
