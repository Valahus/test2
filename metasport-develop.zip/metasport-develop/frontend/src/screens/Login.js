import React, { useState, useEffect } from 'react';
import { Image, Text, View, TouchableOpacity } from 'react-native';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { CustomButton } from '../components/CustomButton';
import { IPConfig } from '../components/IPConfig';
import { useIsFocused } from '@react-navigation/native';

import { mainStyles } from '../styles/mainStyles';
import { auth } from '../firebase/config';
import { signInWithEmailAndPassword } from 'firebase/auth';
import { GreenTextInput } from '../components/GreenTextInput';
import { ScrollView } from 'react-native-gesture-handler';
import LoadingSpinner from '../components/LoadingSpinner.js';
import { CustomPopup } from '../components/CustomPopup';

const Login = ({ navigation }) => {
    const isFocused = useIsFocused();

    const [loading, setLoading] = useState(false);

    const [devPressCount, setDevPressCount] = useState(0);
    const [ipAddr, setIpAddr] = useState(global.backendUrl);
    const [devPopupVisible, setDevPopupVisible] = useState(false);

    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');

    const [errorPopupVisible, setErrorPopupVisible] = useState(false);
    const [errorPopupMessage, setErrorPopupMessage] = useState('');
    const errorMessagesByCode = {
        'auth/invalid-email': 'Invalid E-mail',
        'auth/internal-error': 'An error occured, check your credentials and try again',
        'auth/wrong-password': 'Invalid password',
        'auth/user-not-found': 'User not found for this email, please sign up',
    };

    const onFooterLinkPress = () => {
        navigation.navigate('Registration');
    };

    const onLoginPress = () => {
        setLoading(true);
        signInWithEmailAndPassword(auth, email, password)
            .then((response) => {
                console.debug('User successfully logged in');
                setLoading(false);
            })
            .catch((error) => {
                setLoading(false);
                setErrorPopupMessage(errorMessagesByCode[error.code] || 'An error occured');
                setErrorPopupVisible(true);
            });
    };

    useEffect(() => {
        if (isFocused === false) setDevPressCount(0);
    }, [isFocused]);

    useEffect(() => {
        if (devPressCount === 7) {
            setDevPopupVisible(true);
            setDevPressCount(0);
        }
    }, [devPressCount]);

    if (loading) return <LoadingSpinner />;

    return (
        <ScrollView style={mainStyles.container}>
            <KeyboardAwareScrollView
                style={{ flex: 1, width: '100%' }}
                keyboardShouldPersistTaps='always'
            >
                <TouchableOpacity
                    onPress={() => {
                        setDevPressCount(devPressCount + 1);
                    }}
                >
                    <Image
                        style={mainStyles.logo}
                        source={require('../../assets/trademark/logo-transparent-bg.png')}
                    />
                </TouchableOpacity>
                <GreenTextInput
                    placeholder='E-mail'
                    onChangeText={(text) => setEmail(text)}
                    value={email}
                />
                <GreenTextInput
                    secureTextEntry
                    placeholder='Password'
                    onChangeText={(text) => setPassword(text)}
                    value={password}
                />
                <CustomButton text={'Log in'} onPress={() => onLoginPress()} />
                <View style={mainStyles.footerView}>
                    <Text style={mainStyles.footerText}>
                        Don't have an account ?{' '}
                        <Text onPress={onFooterLinkPress} style={mainStyles.footerLink}>
                            Sign up
                        </Text>
                    </Text>
                </View>
            </KeyboardAwareScrollView>

            <IPConfig
                popupVisible={devPopupVisible}
                setPopupVisible={setDevPopupVisible}
                ipAddr={ipAddr}
                setIpAddr={setIpAddr}
                onClose={() => {
                    global.backendUrl = ipAddr;
                }}
            />

            <CustomPopup
                popupVisible={errorPopupVisible}
                setPopupVisible={setErrorPopupVisible}
                text={errorPopupMessage}
                cancelButton={false}
            />
        </ScrollView>
    );
};

export { Login };
