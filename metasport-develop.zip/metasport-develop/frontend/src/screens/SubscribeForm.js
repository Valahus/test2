import React from 'react';

import { Card, Title } from 'react-native-paper';
import { mainStyles } from '../styles/mainStyles';
import { ScrollView } from 'react-native-gesture-handler';
import { View, Text, TouchableOpacity } from 'react-native';

const BasicCard = () => {
    return (
        <Card style={mainStyles.basicCard}>
            <Card.Content>
                <View style={mainStyles.subContext}>
                    <Title style={mainStyles.titleText}>Basic - athlete</Title>
                    <Title style={mainStyles.titlePrice}>0$/month</Title>
                    <View style={{ padding: 20 }}>
                        <Text style={mainStyles.textSubscribe}>
                            • Enjoy 100% of the MetaSport experience
                        </Text>
                        <Text style={mainStyles.textSubscribe}>• Free</Text>
                        <Text style={mainStyles.textSubscribe}>• Contains partner advertising</Text>
                    </View>
                </View>
            </Card.Content>
        </Card>
    );
};

const PremiumCard = () => {
    return (
        <Card style={mainStyles.premiumCard}>
            <Card.Content>
                <View style={mainStyles.subContext}>
                    <Title style={mainStyles.titleText}>Premium - athlete</Title>
                    <Title style={mainStyles.titlePrice}>5$/month</Title>
                    <View style={{ padding: 20 }}>
                        <Text style={mainStyles.textSubscribe}>
                            • 100% MetaSport without any advertising
                        </Text>
                        <Text style={mainStyles.textSubscribe}>• 20% more screen space</Text>
                    </View>
                </View>
            </Card.Content>
        </Card>
    );
};

const PartnerCard = () => {
    return (
        <Card style={mainStyles.partnerCard}>
            <Card.Content>
                <View style={mainStyles.subContext}>
                    <Title style={mainStyles.titleText}>Premium - athlete</Title>
                    <Title style={mainStyles.titlePrice}>5$/month</Title>
                    <View style={{ padding: 20 }}>
                        <Text style={mainStyles.textSubscribe}>
                            • Made for our sport parners (gyms, clubs, etc)
                        </Text>
                        <Text style={mainStyles.textSubscribe}>
                            • It allows you to create your own sport sessions and invite athelets
                            and possible clients
                        </Text>
                    </View>
                </View>
            </Card.Content>
        </Card>
    );
};

const SubscribeForm = () => {
    return (
        <View>
            <ScrollView style={mainStyles.subContainer}>
                <TouchableOpacity>
                    <BasicCard />
                </TouchableOpacity>
                <TouchableOpacity>
                    <PremiumCard />
                </TouchableOpacity>
                <TouchableOpacity>
                    <PartnerCard />
                </TouchableOpacity>
            </ScrollView>
        </View>
    );
};

export { SubscribeForm };
