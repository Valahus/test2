import React, { useEffect, useState } from 'react';

import axios from 'axios';
import Modal from 'react-native-modal';
import { Card } from 'react-native-paper';
import * as Location from 'expo-location';
import Icon from 'react-native-vector-icons/FontAwesome';
import { ScrollView, Text, TouchableOpacity, View, Switch, RefreshControl } from 'react-native';
import { CustomButton } from '../components/CustomButton';
import { useIsFocused, useNavigation } from '@react-navigation/native';

import { Session } from './Session';
import { mainStyles } from '../styles/mainStyles';
import { SportsPicker } from '../components/SportsPicker';
import { LevelsPicker } from '../components/LevelsPicker';
import LoadingSpinner from '../components/LoadingSpinner.js';

const Home = ({ props, extraData, route }) => {
    const isFocused = useIsFocused();
    const navigation = useNavigation();

    const [loading, setLoading] = useState(false);

    /* Pagination */
    const pageSize = 10;
    const [moreData, setMoreData] = useState(true);

    const [sessions, setSessions] = useState([]);

    /* Location */
    const [locationFilteringEnabled, setLocationFilteringEnabled] = useState(false);
    const [canAskAgainLocation, setCanAskAgainLocation] = useState(true);
    const [location, setLocation] = useState(null);
    const [locationName, setLocationName] = useState(null);

    /* Filters */
    const [offset, setOffset] = useState(0);
    const [filtersRefresh, setFiltersRefresh] = useState(true);
    const [filtersVisible, setFiltersVisible] = useState(false);
    const [selectedSports, setSelectedSports] = useState([]);
    const [selectedLevels, setSelectedLevels] = useState([]);

    const userID = extraData.uid;

    const removeItemFromArray = function (array, item) {
        const index = array.indexOf(item);
        if (index > -1) {
            array.splice(index, 1);
            return true;
        }
        return false;
    };

    const collectSessions = function (reset_sessions = false) {
        let currentOffset = offset;
        if (reset_sessions === true) {
            setLoading(true);
            setMoreData(true);
            setOffset(0);
            currentOffset = 0;
        }

        const filters = {
            sport_id: selectedSports.length > 0 ? selectedSports.map((sport) => sport.id) : null,
            level:
                selectedLevels.length > 0
                    ? selectedLevels.map((level) => level.value.toString())
                    : null,
        };

        let sessionsUrl = `${global.backendUrl}/sessions/filters?skip=${currentOffset}&limit=${pageSize}`;
        if (locationFilteringEnabled && location && location.coords)
            sessionsUrl += `&latitude=${location.coords.latitude}&longitude=${location.coords.longitude}`;
        axios
            .post(sessionsUrl, filters)
            .then((res) => {
                if (res.data.length == 0) setMoreData(false);
                let uniqueSessionsIDs = [];
                let currentSessions = reset_sessions === true ? [] : sessions;
                const uniqueSessions = [...currentSessions, ...res.data].filter((element) => {
                    if (!uniqueSessionsIDs.includes(element.id)) {
                        uniqueSessionsIDs.push(element.id);
                        return true;
                    }
                    return false;
                });
                setSessions(uniqueSessions);
                setLoading(false);
            })
            .catch((error) => {
                console.error(JSON.stringify(error));
                setLoading(false);
            });
    };

    const askPermissionForLocation = async function () {
        try {
            let { canAskAgain, status } = await Location.requestForegroundPermissionsAsync();
            setCanAskAgainLocation(canAskAgain);
            if (status !== 'granted') setLocationFilteringEnabled(false);
            else {
                let currentLocation = await Location.getCurrentPositionAsync({});

                const response = await fetch(
                    `https://nominatim.openstreetmap.org/reverse?lat=${currentLocation.coords.latitude}&lon=${currentLocation.coords.longitude}&format=json`
                );
                const json = await response.json();
                setLocationName(json.display_name);
                setLocation(currentLocation);
                setLocationFilteringEnabled(true);
            }
        } catch (error) {
            setLocationFilteringEnabled(false);
        }
    };

    useEffect(() => {
        if (!location) {
            (async () => {
                askPermissionForLocation();
            })();
        }
        collectSessions();
    }, [locationFilteringEnabled, offset]);

    useEffect(() => {
        collectSessions(true);
    }, [filtersRefresh]);

    const [refreshing, setRefreshing] = React.useState(false);

    const onRefresh = React.useCallback(() => {
        setRefreshing(true);
        collectSessions(true);
        setRefreshing(false);
    }, []);

    useEffect(() => {
        if (isFocused === true && route.params?.refresh === true) {
            setRefreshing(true);
            collectSessions(true);
            setRefreshing(false);
            route.params.refresh = false;
        }
    }, [isFocused]);

    if (loading) return <LoadingSpinner />;

    return (
        <ScrollView
            style={mainStyles.container}
            refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
        >
            <TouchableOpacity
                style={{ marginTop: 25, alignSelf: 'flex-end' }}
                onPress={() => setFiltersVisible(true)}
            >
                <Icon name='filter' size={25} color='black' />
            </TouchableOpacity>
            <View style={{ flexDirection: 'row', flex: 1, flexWrap: 'wrap' }}>
                {selectedSports &&
                    selectedSports.map((selectedSport, index) => {
                        return (
                            <Text
                                key={index}
                                onPress={() => {
                                    if (removeItemFromArray(selectedSports, selectedSport))
                                        setFiltersRefresh(!filtersRefresh);
                                }}
                                style={[
                                    mainStyles.cardLabels,
                                    {
                                        color: 'black',
                                        backgroundColor: 'white',
                                    },
                                ]}
                            >
                                {`${selectedSport.label} \u2716`}
                            </Text>
                        );
                    })}
                {selectedLevels &&
                    selectedLevels.map((selectedLevel, index) => {
                        return (
                            <Text
                                key={index}
                                onPress={() => {
                                    if (removeItemFromArray(selectedLevels, selectedLevel))
                                        setFiltersRefresh(!filtersRefresh);
                                }}
                                style={[
                                    mainStyles.cardLabels,
                                    {
                                        color: 'black',
                                        backgroundColor: 'white',
                                    },
                                ]}
                            >
                                {`${selectedLevel.label} \u2716`}
                            </Text>
                        );
                    })}
            </View>
            {sessions && sessions.length > 0 ? (
                sessions.map((session, index) => {
                    return (
                        <TouchableOpacity
                            key={index}
                            activeOpacity={1}
                            onPress={() =>
                                navigation.navigate('SessionDetails', {
                                    session: session,
                                    userID: userID,
                                })
                            }
                        >
                            <Session session={session} userID={userID} />
                        </TouchableOpacity>
                    );
                })
            ) : (
                <Card style={[mainStyles.card]}>
                    <Card.Title title={'Oups, no session for now'} />
                    <Card.Content style={mainStyles.cardContent}>
                        <TouchableOpacity onPress={() => navigation.navigate('CreateSession')}>
                            <Text
                                style={[
                                    mainStyles.cardLabels,
                                    {
                                        color: 'white',
                                        backgroundColor: 'green',
                                    },
                                ]}
                            >
                                {'Create one here'}
                            </Text>
                        </TouchableOpacity>
                    </Card.Content>
                </Card>
            )}
            <View style={{ marginTop: 10, marginBottom: 15 }}>
                {moreData ? (
                    <CustomButton text={'Load more'} onPress={() => setOffset(offset + pageSize)} />
                ) : (
                    <Text style={{ alignSelf: 'center', fontWeight: 'bold' }}>
                        No more sessions for now
                    </Text>
                )}
            </View>

            <Modal
                isVisible={filtersVisible}
                animationIn='slideInRight'
                animationOut='slideOutRight'
                style={{ margin: 0 }}
            >
                <Card style={mainStyles.filtersCard}>
                    <View style={{ flex: 1 }}>
                        <TouchableOpacity
                            onPress={() => {
                                setFiltersVisible(false);
                                setFiltersRefresh(!filtersRefresh);
                            }}
                        >
                            <Icon
                                style={{
                                    padding: 0,
                                    marginBottom: 15,
                                }}
                                size={22}
                                name='close'
                                color='grey'
                            />
                        </TouchableOpacity>
                        <SportsPicker
                            selectedSports={selectedSports}
                            setSelectedSports={setSelectedSports}
                            isMulti={true}
                        />
                        {canAskAgainLocation && (
                            <View
                                style={{
                                    flexDirection: 'row',
                                    marginTop: 10,
                                    justifyContent: 'space-between',
                                }}
                            >
                                <Text style={mainStyles.text}>Filter sessions by location</Text>
                                <Switch
                                    trackColor={{ false: '#767577', true: '#81b0ff' }}
                                    thumbColor={locationFilteringEnabled ? '#f5dd4b' : '#f4f3f4'}
                                    onValueChange={() =>
                                        setLocationFilteringEnabled(!locationFilteringEnabled)
                                    }
                                    value={locationFilteringEnabled}
                                />
                            </View>
                        )}
                        <LevelsPicker
                            selectedLevels={selectedLevels}
                            setSelectedLevels={setSelectedLevels}
                            isMulti={true}
                        />
                    </View>
                </Card>
            </Modal>
        </ScrollView>
    );
};

export { Home };
