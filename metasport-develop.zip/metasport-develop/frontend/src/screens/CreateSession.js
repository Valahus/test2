import React, { useEffect, useState } from 'react';
import { View, Text, TextInput } from 'react-native';
import axios from 'axios';
import Checkbox from 'expo-checkbox';
import { useIsFocused } from '@react-navigation/native';
import NumericInput from 'react-native-numeric-input';
import { format } from 'date-fns';
import { CustomPopup } from '../components/CustomPopup';

import firebase from 'firebase/compat/app';
import { Card } from 'react-native-paper';
import { CustomButton } from '../components/CustomButton';

import { GooglePlacesAutocomplete } from 'react-native-google-places-autocomplete';

import { mainStyles } from '../styles/mainStyles';
import { SportsPicker } from '../components/SportsPicker';
import { LevelsPicker } from '../components/LevelsPicker';

import DatePickerCustom from '../components/DatePickerCustom';
import TimePickerCustom from '../components/TimePickerCustom';

const CreateSession = (props) => {
    const isFocused = useIsFocused();

    const [step, setStep] = useState(1);
    const [canGoNext, setCanGoNext] = useState(false);
    const lastStep = 7;

    const [description, setDescription] = useState('');
    const [selectedSports, setSelectedSports] = useState([]);
    const [selectedLevels, setSelectedLevels] = useState([]);
    const [hasMaxParticipants, setHasMaxParticipants] = useState(true);
    const [maxParticipants, setMaxParticipants] = useState(2);
    const [isIndoor, setIndoor] = useState(false);

    const [geoLat, setGeoLat] = useState(-1);
    const [geoLng, setGeoLng] = useState(-1);
    const [locationName, setLocationName] = useState('');

    /* Date and Time Picker */
    const [startDate, setStartDate] = useState(new Date());
    const [startTime, setStartTime] = useState(new Date());
    const [endDate, setEndDate] = useState(new Date());
    const [endTime, setEndTime] = useState(new Date());

    const [errorPopupVisible, setErrorPopupVisible] = useState(false);

    const user = firebase.auth().currentUser;

    function onSessionPress() {
        const sessionCreate = {
            user_id: user.uid,
            start: new Date(
                `${format(startDate, 'MM/dd/yy')} ${format(startTime, 'HH:mm')}`
            ).toISOString(),
            end: new Date(
                `${format(endDate, 'MM/dd/yy')} ${format(endTime, 'HH:mm')}`
            ).toISOString(),
            indoor: isIndoor,
            level: selectedLevels[0].value.toString(),
            location_name: locationName,
            participants_ids: [user.uid],
            lat: geoLat,
            lon: geoLng,
            max_participants: hasMaxParticipants === true ? maxParticipants : -1,
            sport_id: selectedSports[0].id,
            description: description,
        };

        console.debug(JSON.stringify(sessionCreate));

        axios
            .post(`${global.backendUrl}/sessions`, sessionCreate)
            .then((res) => {
                props.navigation.navigate('SessionDetails', {
                    session: res.data,
                    userID: user.uid,
                });
            })
            .catch((e) => {
                setErrorPopupVisible(true);
                console.error(JSON.stringify(e));
            });
    }

    useEffect(() => {
        if (isFocused === false) {
            setStep(1);
            setCanGoNext(false);
            setSelectedLevels([]);
            setSelectedSports([]);
            setDescription('');
            setLocationName('');
            setGeoLat(-1);
            setGeoLng(-1);
        }
    }, [isFocused]);

    useEffect(() => {
        if (selectedSports.length > 0) setCanGoNext(true);
    }, [selectedSports]);

    useEffect(() => {
        if (selectedLevels.length > 0) setCanGoNext(true);
    }, [selectedLevels]);

    const stepsTitles = [
        'Which sport ?',
        'Which level ?',
        'Where ?',
        'Indoor ?',
        'Number of maximum participants',
        'When ?',
        'Describe what you are looking for',
    ];

    const onPressPrevious = function () {
        setCanGoNext(true);
        setStep(step - 1);
    };

    // TODO check order by and in XX days

    const onPressNext = function () {
        if (canGoNext === false) return;
        if ([4, 5, 6].includes(step + 1)) setCanGoNext(true);
        else setCanGoNext(false);
        setStep(step + 1);
    };

    const disabledNextColors = ['#EBEBEB', '#A6A6A6'];

    const getButtonColors = function () {
        if (step === lastStep) return ['rgba(255,90,90,1)', 'rgba(130,5,255,1)'];
        if (canGoNext === true) return null;
        return disabledNextColors;
    };

    if (step === 3)
        return (
            <View
                style={
                    ([mainStyles.container],
                    {
                        justifyContent: 'center',
                        alignItems: 'center',
                        height: '100%',
                    })
                }
            >
                <View
                    style={[
                        {
                            width: '90%',
                            padding: 10,
                            backgroundColor: 'white',
                            height: '85%',
                            marginTop: 45,
                            marginBottom: 15,
                        },
                    ]}
                >
                    <View
                        style={{
                            alignItems: 'center',
                            justifyContent: 'center',
                            flexDirection: 'row',
                            marginBottom: 15,
                        }}
                    >
                        <Text
                            style={{
                                marginBottom: 20,
                                textAlign: 'center',
                                fontSize: 20,
                                fontWeight: 'bold',
                            }}
                        >
                            {stepsTitles[2]}
                        </Text>
                    </View>
                    {locationName ? <Text style={{ marginBottom: 15 }}>{locationName}</Text> : null}
                    <GooglePlacesAutocomplete
                        fetchDetails={true}
                        placeholder='Search'
                        onPress={(data, details) => {
                            setGeoLat(details?.geometry?.location?.lat);
                            setGeoLng(details?.geometry?.location?.lng);
                            setLocationName(details?.formatted_address);
                            setCanGoNext(true);
                        }}
                        listViewDisplayed={true}
                        query={{
                            key: 'AIzaSyC-hsuIotqDKI4MQnOein_u29wV4EtfhI4',
                            language: 'en',
                        }}
                        styles={{
                            textInput: {
                                height: 38,
                                color: '#5d5d5d',
                                fontSize: 16,
                                backgroundColor: '#EDEDED',
                            },
                        }}
                    />
                </View>
                <View
                    style={{
                        marginBottom: 5,
                        flexDirection: 'row',
                        justifyContent: 'space-between',
                        width: '90%',
                        alignItems: 'center',
                    }}
                >
                    {step !== 1 ? (
                        <CustomButton text='Previous' width='30%' onPress={onPressPrevious} />
                    ) : (
                        <View style={{ width: '30%' }}></View>
                    )}
                    {step !== 4 ? (
                        <CustomButton
                            text='Next'
                            width='30%'
                            onPress={onPressNext}
                            colors={getButtonColors()}
                        />
                    ) : null}
                </View>
            </View>
        );

    return (
        <View style={mainStyles.container}>
            <Card
                style={[mainStyles.headerCard, { height: '85%', marginTop: 45, marginBottom: 15 }]}
            >
                <Card.Title
                    style={{ marginBottom: 15 }}
                    title={stepsTitles[step - 1]}
                    titleStyle={{ textAlign: 'center' }}
                />
                <Card.Content>
                    {step === 1 ? (
                        <SportsPicker
                            selectedSports={selectedSports}
                            setSelectedSports={setSelectedSports}
                        />
                    ) : null}
                    {step === 2 ? (
                        <LevelsPicker
                            selectedLevels={selectedLevels}
                            setSelectedLevels={setSelectedLevels}
                        />
                    ) : null}
                    {step === 4 ? (
                        <View
                            style={{
                                flexDirection: 'row',
                                justifyContent: 'space-between',
                                marginBottom: 15,
                            }}
                        >
                            <Text>Indoor</Text>
                            <Checkbox color='grey' value={isIndoor} onValueChange={setIndoor} />
                        </View>
                    ) : null}
                    {step === 5 ? (
                        <View style={{ alignItems: 'center' }}>
                            <View
                                style={{
                                    flexDirection: 'row',
                                    justifyContent: 'space-between',
                                    marginBottom: 15,
                                }}
                            >
                                <Text style={{ width: '85%' }}>Max participants</Text>
                                <Checkbox
                                    color='rgba(8,70,218,0.7)'
                                    value={hasMaxParticipants}
                                    onValueChange={setHasMaxParticipants}
                                />
                            </View>
                            {hasMaxParticipants === true ? (
                                <NumericInput
                                    value={maxParticipants}
                                    onChange={(value) => setMaxParticipants(value)}
                                    totalWidth={300}
                                    totalHeight={45}
                                    iconSize={25}
                                    step={1}
                                    rounded
                                    iconStyle={{ color: 'black' }}
                                    rightButtonBackgroundColor='#E3E3E3'
                                    leftButtonBackgroundColor='#E3E3E3'
                                    minValue={2}
                                />
                            ) : null}
                        </View>
                    ) : null}
                    {step === 6 ? (
                        <>
                            <View>
                                <Text>Start date</Text>
                                <View style={{ flexDirection: 'row', justifyContent: 'center' }}>
                                    <DatePickerCustom date={startDate} setDate={setStartDate} />
                                    <TimePickerCustom time={startTime} setTime={setStartTime} />
                                </View>
                            </View>
                            <View>
                                <Text>End date</Text>
                                <View style={{ flexDirection: 'row', justifyContent: 'center' }}>
                                    <DatePickerCustom date={endDate} setDate={setEndDate} />
                                    <TimePickerCustom time={endTime} setTime={setEndTime} />
                                </View>
                            </View>
                        </>
                    ) : null}
                    {step === 7 ? (
                        <>
                            <Text>Optional : max 160 chars</Text>
                            <TextInput
                                placeholder='Type here...'
                                value={description}
                                onChangeText={(text) => setDescription(text)}
                                style={{ borderWidth: 1, borderColor: '#EDEDED', marginTop: 5 }}
                                multiline
                                editable
                                numberOfLines={4}
                                maxLength={160}
                                underlineColorAndroid='transparent'
                                autoCapitalize='none'
                            />
                        </>
                    ) : null}
                </Card.Content>
            </Card>
            <View
                style={{
                    flexDirection: 'row',
                    justifyContent: 'space-between',
                    width: '100%',
                }}
            >
                {step !== 1 ? (
                    <CustomButton text='Previous' width='30%' onPress={onPressPrevious} />
                ) : (
                    <View style={{ width: '30%' }}></View>
                )}
                <CustomButton
                    text={step === lastStep ? 'Create' : 'Next'}
                    width='30%'
                    onPress={() => {
                        if (step === lastStep) onSessionPress();
                        else onPressNext();
                    }}
                    colors={getButtonColors()}
                />
            </View>
            <CustomPopup
                popupVisible={errorPopupVisible}
                setPopupVisible={setErrorPopupVisible}
                text='An error occured'
                onClose={() => {
                    props.navigation.navigate('Home', { refresh: false });
                }}
                cancelButton={false}
            />
        </View>
    );
};

export { CreateSession };
