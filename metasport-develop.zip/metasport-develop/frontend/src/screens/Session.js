import React from 'react';
import { Text, View, TouchableOpacity } from 'react-native';
import { Card } from 'react-native-paper';

import { mainStyles } from '../styles/mainStyles';
import { levelsDetails, sportsIcons, getDaysUntilSessionSentence } from '../utils/commons';

const Session = ({ session, userID }) => {
    const getParticipantsLabelComponent = function () {
        if (session.max_participants) {
            if (session.participants_ids.length == session.max_participants)
                return (
                    <TouchableOpacity>
                        <Text
                            style={[
                                mainStyles.cardLabels,
                                {
                                    backgroundColor: '#94DFFF',
                                },
                            ]}
                        >
                            {`full session`}
                        </Text>
                    </TouchableOpacity>
                );
            return (
                <TouchableOpacity>
                    <Text
                        style={[
                            mainStyles.cardLabels,
                            {
                                borderWidth: 1,
                                borderColor: 'black',
                                backgroundColor: 'white',
                            },
                        ]}
                    >
                        {`${session.participants_ids.length}/${session.max_participants} participants`}
                    </Text>
                </TouchableOpacity>
            );
        }

        if (session.participants_ids.length > 1)
            return (
                <TouchableOpacity>
                    <Text
                        style={[
                            mainStyles.cardLabels,
                            {
                                color: 'white',
                                backgroundColor: 'grey',
                            },
                        ]}
                    >
                        {`${session.participants_ids.length} participants`}
                    </Text>
                </TouchableOpacity>
            );
    };

    return (
        <Card style={[mainStyles.card, { maxWidth: '100%' }]}>
            <View
                style={{
                    flexDirection: 'row',
                    padding: 10,
                    justifyContent: 'space-between',
                }}
            >
                <Text style={{ fontSize: 20, fontWeight: 'bold' }}>
                    {sportsIcons[session.sport.name]} {session.sport.name}
                </Text>

                <Text
                    style={{
                        color: 'grey',
                        fontSize: 14,
                    }}
                >
                    {getDaysUntilSessionSentence(session.start)}
                </Text>
            </View>
            <Card.Content style={mainStyles.cardContent}>
                <TouchableOpacity>
                    <Text
                        style={[
                            mainStyles.cardLabels,
                            {
                                color: 'green',
                                borderWidth: 1,
                                borderColor: 'green',
                            },
                        ]}
                    >
                        {session.location_name}
                    </Text>
                </TouchableOpacity>
                <TouchableOpacity>
                    <Text
                        style={[
                            mainStyles.cardLabels,
                            {
                                color: levelsDetails[session.level].color,
                                borderWidth: 1,
                                borderColor: levelsDetails[session.level].color,
                            },
                        ]}
                    >
                        {levelsDetails[session.level].name}
                    </Text>
                </TouchableOpacity>
                {getParticipantsLabelComponent()}
            </Card.Content>
        </Card>
    );
};

export { Session };
